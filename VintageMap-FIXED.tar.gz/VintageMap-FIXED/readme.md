# Vintage Strava Map

Display your Strava activities on a beautiful vintage-style map.

## 🎉 Latest Update - Version 1.1.0

**Major bug fixes and improvements!**

### What's Fixed
- ✅ Fixed critical `aasync` typo that prevented activity loading
- ✅ Added missing `initMap()` function - map now loads correctly
- ✅ Added missing `loadActivitiesForDateRange()` - date filtering now works
- ✅ Sequential activity loading prevents API overload
- ✅ Progress indicator shows loading status
- ✅ Better error handling and notifications

### New Features
- 📊 Progress bar when loading multiple activities
- 🔄 Sequential loading with delays (no more API overwhelm)
- ✅ Activities continue loading even if one fails
- 🎯 Better user feedback with notifications

See [CHANGELOG.md](CHANGELOG.md) for complete details.

---

## Setup Instructions

1. **Get Strava API Credentials**
   - Go to https://www.strava.com/settings/api
   - Create a new application
   - Note your Client ID and Client Secret

2. **Configure the Application**
   - Open `config.php`
   - Replace `YOUR_CLIENT_ID_HERE` with your Client ID
   - Replace `YOUR_CLIENT_SECRET_HERE` with your Client Secret

3. **Upload Files**
   - Upload all files to your web server
   - Ensure PHP sessions are enabled
   - Make sure both `vintagemap.html` and `strava-fix.js` are in the same directory

4. **Test**
   - Visit `vintagemap.html`
   - Click "Connect with Strava"
   - Authorize the application
   - Select date range or activities to display

## Features
- 🗺️ Vintage-styled maps using MapTiler
- 🚴 Connect with Strava OAuth
- 📅 Date range filtering for activities
- ✅ Select multiple activities to display
- 📈 Elevation profiles
- 📊 Route statistics
- 🏷️ Trail labels
- 📱 Responsive design

## How to Use

### Upload GPX Files
1. Click the file input to select GPX files from your computer
2. Multiple files can be selected at once
3. Routes appear immediately on the map

### Connect to Strava
1. Click "Connect with Strava"
2. Authorize the application
3. Select a date range (defaults to June 2024)
4. Click "Load Activities" to see your activities
5. Check the boxes for activities you want to display
6. Click "Load Selected" to add them to the map

### View Statistics
- Click "📊 Statistics" to see total distance, climb, and descent
- Click "📈 Elevation" to view elevation profile
- Click "🏷️ Labels" to see list of all routes with details

## Technical Details

### Sequential Loading
The application now loads activities one at a time with a 500ms delay between each request. This prevents overwhelming the Strava API and ensures reliable loading of multiple activities.

### Progress Tracking
When loading multiple activities, you'll see a progress indicator showing:
- Current activity being loaded
- Total progress (e.g., "Loading 3/10 activities...")
- Percentage complete

### Error Handling
If an activity fails to load, the application:
- Logs the error to console
- Continues with remaining activities
- Shows a summary at the end

## Files Structure

```
/VintageMap/
├── vintagemap.html       # Main application (✨ UPDATED)
├── strava-fix.js         # ✨ NEW: Sequential loading & fixes
├── config.php            # Strava API credentials
├── strava-auth.php       # OAuth handler
├── strava-activities.php # Activity fetching
├── strava-gpx.php        # GPX conversion
├── strava-disconnect.php # Logout handler
├── check-session.php     # Session validation
└── CHANGELOG.md          # ✨ NEW: Detailed change log
```

## Configuration

### Customizing Load Speed
Edit `strava-fix.js` to change the delay between activity requests:

```javascript
const CONFIG = {
    ACTIVITY_LOAD_DELAY: 500,  // Change to 250 for faster (but riskier) loading
    MAX_CONCURRENT_ACTIVITIES: 10,
    COLORS: ['#8b4513', '#2d5016', '#8b0000', '#4a5d23', '#704214']
};
```

### Map Center
The map centers on Soest, Utrecht, Netherlands by default. To change this, edit the `initMap()` function in `vintagemap.html`:

```javascript
center: [5.1214, 52.0907], // [longitude, latitude]
zoom: 8
```

## Troubleshooting

### Activities won't load
- Check browser console (F12) for errors
- Verify Strava OAuth is connected
- Check that PHP files are accessible
- Try loading one activity first to test

### Map doesn't appear
- Verify MapTiler API key is correct
- Check browser console for errors
- Ensure internet connection is active

### "Select Activities" button doesn't respond
- Clear browser cache
- Reload the page
- Check console for JavaScript errors

### Progress bar stuck
- Wait for timeout (activities may be loading slowly)
- Refresh the page and try again with fewer activities
- Check network tab in DevTools for failed requests

## Browser Compatibility
- ✅ Chrome (recommended)
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Mobile browsers

## Performance Notes
- Loading 1 activity: ~0.5 seconds
- Loading 5 activities: ~2.5 seconds (sequential)
- Loading 10 activities: ~5 seconds (with progress bar)
- Loading 20+ activities: ~10-15 seconds (confirmation dialog shown)

## Security Notes
- Never commit config.php with real credentials
- Use HTTPS in production
- Keep Client Secret secure
- Sessions are configured with secure cookies

## Support
For issues or questions, please create an issue on GitHub.

## License
Free to use for personal projects.

## Credits
- Maps by [MapTiler](https://www.maptiler.com/)
- Data from [Strava](https://www.strava.com/)
- Built with vanilla JavaScript (no frameworks!)

---

**Version**: 1.1.0  
**Last Updated**: September 30, 2025